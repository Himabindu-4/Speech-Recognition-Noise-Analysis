# Speech Recognition Robustness in Noisy Environments

Case Study – Option A: Robustness in Noisy Environments (Automotive / Smart Home)

This repository evaluates how background noise affects Automatic Speech Recognition (ASR) and whether spectral-subtraction denoising can recover transcription accuracy.

## Research question

How does background noise at 20 dB, 10 dB, and 0 dB SNR affect Whisper Base transcription accuracy, and how much can a spectral-subtraction preprocessing stage reduce the degradation?

## Experimental pipeline

Clean LibriSpeech audio
→ add MUSAN noise at controlled SNR
→ Whisper Base baseline
→ spectral subtraction
→ Whisper Base with denoising
→ WER / CER / latency / RTF
→ plots + spectrogram + error analysis

## Important

The repository contains **code and configuration, not the datasets or generated results**. Do not invent results. Run the experiment and commit the generated CSV/PNG files after verification.

## Recommended environment

Use Python 3.11. OpenAI's Whisper repository currently documents Python 3.8–3.11 compatibility and lists the Base model at about 74M parameters and about 1 GB VRAM requirement.

Install FFmpeg before installing Python packages.

### Windows

1. Install Python 3.11.
2. Install FFmpeg and make sure `ffmpeg` works in PowerShell:
   ```powershell
   ffmpeg -version
   ```
3. Create the environment:
   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

## Data

### LibriSpeech

The default configuration uses the LibriSpeech `test-clean` split. The official corpus is approximately 1000 hours of 16-kHz read English speech; `test-clean` is an official evaluation split.

Download it automatically with:

```powershell
python scripts\download_librispeech.py
```

The script uses torchaudio's LibriSpeech dataset interface and downloads only `test-clean`.

### MUSAN

MUSAN contains music, speech, and noise recordings. It is large, so it is intentionally not stored in Git.

Download/extract MUSAN manually and place it as:

```text
data/
  musan/
    music/
    noise/
    speech/
```

The experiment defaults to the `noise` category. You can change this in `configs/config.yaml`.

## Quick experiment

Start with a small run so you can verify the pipeline:

```powershell
python scripts\prepare_manifest.py --limit 20
python scripts\run_experiment.py --limit 20
python scripts\make_plots.py
python scripts\make_spectrogram.py
python scripts\make_error_analysis.py --n 5
```

After confirming everything works, run a larger evaluation:

```powershell
python scripts\prepare_manifest.py --limit 100
python scripts\run_experiment.py --limit 100
python scripts\make_plots.py
python scripts\make_spectrogram.py
python scripts\make_error_analysis.py --n 5
```

The exact number of samples, speakers, total duration, and results must be reported from the generated files, not guessed.

## Output files

Generated files appear under:

```text
outputs/
  audio/
  results/
  figures/
```

Important outputs:

- `outputs/results/experiment_results.csv`
- `outputs/results/summary_by_snr.csv`
- `outputs/results/error_cases.csv`
- `outputs/figures/wer_vs_snr.png`
- `outputs/figures/cer_vs_snr.png`
- `outputs/figures/system_metrics.png`
- `outputs/figures/annotated_spectrogram.png`

## Reproducibility

Record these in the final report:

- operating system
- Python version
- CPU/GPU
- Whisper model
- number of audio samples
- total duration
- number of unique speakers
- SNR values
- noise category
- WER
- CER
- latency
- RTF
- denoising parameters

## Git

After running and checking the experiment:

```powershell
git init
git add .
git commit -m "Initial ASR noise robustness case study"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Speech-Recognition-Noise-Analysis.git
git push -u origin main
```

Do not commit datasets, model caches, virtual environments, or personal files.
